// login
export const LOGIN_REQUEST = 'LOGIN_REQUEST';
export const LOGIN_RESPONSE = 'LOGIN_RESPONSE';

//home
export const HOME_REQUEST = 'HOME_REQUEST';
export const HOME_RESPONSE = 'HOME_RESPONSE';
