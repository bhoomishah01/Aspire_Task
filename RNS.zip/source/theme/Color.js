export default {
    Colorwhite: '#ffffff',
    ColorBlack: '#000000',
  };
  