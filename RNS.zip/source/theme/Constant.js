export default {
  baseURL: 'https://staging.2excel.com.au/onlinephoto/api/v1.0/',
  sessId: 'sessId',
};
